import math
import sympy as sm

fx = input("Enter the function: ")
dfx = input("Enter the derivate of the function: ")
x0 = input("Enter the initial value x0: ")
tol = input("Enter tolerance: ")
N = input("Enter the iterations number N: ")

def newton(fx, d_fx, x_initial, tolerance, iterations):
   x_initial = float(x_initial)
   tolerance = float(tolerance)
   iterations = int(iterations)
   results = []
   iters =[]
   xi = []
   functions = []
   E = []

   if tolerance < 0:
     print("Error, the tolerance has to be positive") 
   elif iterations <= 0:
     print("Error, the maximum iterations has to be positive and greater than zero") 
   else:
      i = 0
      x = sm.symbols('x')
      function = sm.simplify(fx).subs(x, x_initial)
      d_function = sm.simplify(d_fx).subs(x, x_initial)
      x_previous = x_initial
      x_current = x_initial
      condition = True
      iters.append(i) 
      xi.append("{:.10f}".format(x_current))
      functions.append(function)
      E.append(" ")
      while condition != False:
         x_current = x_previous - (function/d_function)
         function = sm.simplify(fx).subs(x, x_current)
         d_function = sm.simplify(d_fx).subs(x, x_current)
         error = abs(x_previous-x_current)
         if function == 0 or error < tolerance:
            condition = False
         i += 1
         iters.append(i) 
         xi.append("{:.10f}".format(x_current))
         functions.append(function)
         E.append(error)
         x_previous = x_current
      results.extend([iters, xi, functions, E])
      print("|  iter |      xi      |     f(xi)     |      E       |")
      print(f"|   {iters[0]}   | {xi[0]} |"+" %e "%functions[0]+f"|      {E[0]}       |")
      dato = 1
      while dato < len(iters):
         print(f"|   {iters[dato]}   | {xi[dato]} "+"| %e | %e |"%(functions[dato], E[dato]))
         dato += 1
      print(f"an approximation of the root was found in {x_current}")

newton(fx, dfx, x0, tol, N)