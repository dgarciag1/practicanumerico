import math
import sympy as sm

fx = input("Enter the function: ")
a = input("Enter the lower point (a) of the interval: ")
b = input("Enter the upper point (b) of the interval: ")
tol = input("Enter tolerance: ")
N = input("Enter the maximum iterations N: ")

def false_rule(fx, a_point, b_point, tolerance, iterations):
   a_point = float(a_point)
   b_point = float(b_point)
   tolerance = float(tolerance)
   iterations = int(iterations)
   results = []
   iters =[]
   ai = []
   xm = []
   bi = []
   fxm = []
   E = []

   if tolerance < 0:
     print("Error, the tolerance has to be positive") 
   elif iterations <= 0:
     print("Error, the maximum iterations has to be positive and greater than zero") 
   else:
      i = 0
      x = sm.symbols('x')
      a_current = a_point
      b_current = b_point
      function_a = sm.simplify(fx).subs(x, a_current)
      function_b = sm.simplify(fx).subs(x, b_current)
      xm_current = a_current - (((function_a)*(a_current-b_current))/(function_a-function_b))
      function_xm = sm.simplify(fx).subs(x, xm_current)
      a_previous = a_current
      b_previous = b_current
      xm_previous = xm_current
      function_a_previous = function_a
      function_b_previous = function_b
      function_xm_previous = function_xm
      condition = True
      iters.append(i) 
      ai.append("{:.10f}".format(a_current))
      bi.append("{:.10f}".format(b_current))
      xm.append("{:.10f}".format(xm_current))
      fxm.append(function_xm)
      E.append(" ")
      while condition != False:
         if(function_a_previous*function_xm_previous)<0:
            a_current = a_previous
         else:
            a_current = xm_previous

         if(function_b_previous*function_xm_previous)<0:
            b_current = b_previous
         else:
            b_current = xm_current 

         function_a = sm.simplify(fx).subs(x, a_current)
         function_b = sm.simplify(fx).subs(x, b_current)
         xm_current = a_current - (((function_a)*(a_current-b_current))/(function_a-function_b))
         function_xm = sm.simplify(fx).subs(x, xm_current)
         error = abs(xm_previous-xm_current)
         i += 1
         iters.append(i) 
         ai.append("{:.10f}".format(a_current))
         bi.append("{:.10f}".format(b_current))
         xm.append("{:.10f}".format(xm_current))
         fxm.append(function_xm)
         E.append(error)
         if (function_xm == 0) or (error < tolerance) or (i>iterations):
            condition = False
         a_previous = a_current
         b_previous = b_current
         xm_previous = xm_current
         function_a_previous = function_a
         function_b_previous = function_b
         function_xm_previous = function_xm
         
      results.extend([iters, ai, xm, bi, fxm, E])
      print("|  iter |      ai      |      xm      |       bi      |     f(xm)     |      E       |")
      print(f"|   {iters[0]}   | {ai[0]} | {xm[0]} |  {bi[0]} |"+" %e "%fxm[0]+f"|      {E[0]}       |")
      dato = 1
      while dato < len(iters):
         print(f"|   {iters[dato]}   | {ai[dato]} | {xm[dato]} |  {bi[dato]} "+"| %e  | %e |"%(fxm[dato],E[dato]))
         dato += 1
      print(f"an approximation of the root was found in {xm_current}")

false_rule(fx, a, b, tol, N)