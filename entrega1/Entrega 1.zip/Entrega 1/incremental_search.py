import math
import sympy as sm

fx = input("Enter the function: ")
x0 = input("Enter the initial value x0: ")
delta = input("Enter delta value: ")
N = input("Enter the iterations number N: ")

def incremental_search(fx, x_initial, delta_value, iterations):
   x_initial = float(x_initial)
   delta_value = float(delta_value)
   iterations = int(iterations)
   results = []

   if delta_value <= 0:
     print("Error, the delta value has to be positive and greater than zero") 
   elif iterations <= 0:
     print("Error, the maximum iterations has to be positive and greater than zero") 
   else:
      iteration = 0
      x = sm.symbols('x')
      x_current = x_initial
      x_previous = x_current
      function_previous = sm.simplify(fx).subs(x, x_initial)
      function_current = sm.simplify(fx).subs(x, x_initial)
      while iteration < iterations:
         x_current = x_previous + delta_value
         function_current = sm.simplify(fx).subs(x, x_current)
         if function_previous*function_current < 0:
            results.append(["{:.10f}".format(x_previous),"{:.10f}".format(x_current)])        
         x_previous = x_current
         function_previous = function_current
         iteration += 1
      for result in results:
         print(f"There is a root of f in: [{result[0]},{result[1]}]")

incremental_search(fx, x0, delta, N)